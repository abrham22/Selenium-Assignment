import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class AutomateAddisfortune {
    private WebDriver driver;
    private String baseUrl, blogUrl;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/usr/local/share/chromedriver");
        driver = new ChromeDriver();
        baseUrl = "https://addisfortune.net";
        blogUrl = "http://localhost/blogNews";
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void testUntitledTestCase() throws Exception {
        driver.get(baseUrl);
        WebElement newsContener = driver.findElement(
                By.xpath("//*[@id=\"addisfortune-main\"]/div/div[1]/div[2]/div"));

        List<WebElement> newsTitles = newsContener.findElements(By.xpath("//h3"));
        List<WebElement> newsContents = newsContener.findElements(By.xpath("//div"));

        String[][] stringNews = new String[newsTitles.size()][2];
        int i = 0;

        for(WebElement newsTitle: newsTitles){
            String title = newsTitle.findElement(By.xpath("//a")).getText();
            stringNews[i][0] = title;
            i++;
        }

        i = 0;
        for(WebElement newsContent : newsContents){
            String title = newsContent.findElement(By.xpath("//div[2]/p")).getText();
            stringNews[i][1] = title;
            i++;
            if (i == newsTitles.size()) break;
        }

        driver.get(blogUrl);
        for(i = 0; i < newsTitles.size(); i++){
            driver.findElement(By.xpath("//input[@type='text']")).sendKeys(stringNews[i][0]);
            driver.findElement(By.xpath("//textarea[@name='content']")).sendKeys(stringNews[i][1]);
            driver.findElement(By.xpath("//input[@type='submit']")).click();
        }
    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
    }
}
