import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.fail;

public class AutomateFacebookNotification {
    private WebDriver driver;
    private String baseUrl;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/usr/local/share/chromedriver");
        driver = new ChromeDriver();
        baseUrl = "https://www.facebook.com/";
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void testUntitledTestCase() throws Exception {
        driver.get(baseUrl);
        WebElement emailInput = driver.findElement(By.xpath("//*[@id=\"email\"]"));
        emailInput.sendKeys("email@email.com");
        WebElement passwordInput = driver.findElement(By.xpath("//*[@id=\"pass\"]"));
        passwordInput.sendKeys("password");
        WebElement loginBtn = driver.findElement(By.xpath("//*[@value=\"Log In\"]"));
        loginBtn.click();

        WebElement notificationSpan = driver.findElement(By.xpath("//*[@id=\"notificationsCountValue\"]"));
        String notifications = notificationSpan.getText();

        System.out.printf("You have " + notifications + " notification.");
    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
    }
}
